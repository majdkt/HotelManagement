public class Story {
    public static void main(String[] args) {
        System.out.println("Hello There! I'm Majd, Your assistant in Berlin.");
        System.out.println("I have been informed that 10 of" +
                " the top authors of the world\n" +
                "are coming to Berlin for a specific event.\n" +
                "I am here to assist you through booking rooms for them and\n" +
                "their companions in the best hotels in Berlin!\n" );
        System.out.println("------------------------------------------------");
        System.out.println("Now, Let's start booking rooms for our guests");
        Booking1.main(args);
    }
}
